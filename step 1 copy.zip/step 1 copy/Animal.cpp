/**
 * @file Animal.cpp
 *
 * @author Ishita Saripalle
 */

#include "Animal.h"

/**
 * Destructor
 */
Animal::~Animal()
{
}